package com.mycompany.clubdeportivo;

public class Entrenador {
    
    private String nombre;
    private String especialidad;
    private int experiencia;

    public Entrenador(String nombre, String especialidad, int experiencia) {
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.experiencia = experiencia;
    }

    @Override
    public String toString() {
        return "Entrenador [Nombre: " + nombre + ", Especialidad: " + especialidad + ", Años de Experiencia: " + experiencia + "]";
    }
}
