package com.mycompany.clubdeportivo;

public class Deportista {
    
    private String nombre;
    private int edad;
    private String deporte;

    public Deportista(String nombre, int edad, String deporte) {
        this.nombre = nombre;
        this.edad = edad;
        this.deporte = deporte;
    }

    @Override
    public String toString() {
        return "Deportista [Nombre: " + nombre + ", Edad: " + edad + ", Deporte: " + deporte + "]";
    }
}
