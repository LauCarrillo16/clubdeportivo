package com.mycompany.clubdeportivo;

public class Equipo {
    
    private String nombre;
    private String categoria;

    public Equipo(String nombre, String categoria) {
        this.nombre = nombre;
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Equipo [Nombre: " + nombre + ", Categoria: " + categoria + "]";
    }
}
