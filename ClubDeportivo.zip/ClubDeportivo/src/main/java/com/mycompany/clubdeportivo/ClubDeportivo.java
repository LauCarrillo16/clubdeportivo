package com.mycompany.clubdeportivo;

import java.util.ArrayList;
import java.util.Scanner;

public class ClubDeportivo {
    
    private static ArrayList<Entrenador> entrenadores = new ArrayList<>();
    private static ArrayList<Deportista> deportistas = new ArrayList<>();
    private static ArrayList<Equipo> equipos = new ArrayList<>();

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        int opt;
        
        do {
            System.out.println("--- Bienvenido a tu Sistema de Gestion de Club Deportivo ---");
            System.out.println("1. Gestion de Entrenadores.");
            System.out.println("2. Gestion de Deportistas.");
            System.out.println("3. Gestion de Equipos.");
            System.out.println("4. Salir.");
            opt = scanner.nextInt();
            
            switch (opt) {
                case 1:
                    gestionarEntrenadores(scanner);
                    break;
                case 2:
                    gestionDeportistas(scanner);
                    break;
                case 3:
                    gestionEquipos(scanner);
                    break;
                case 4:
                    System.out.println("Estas Saliendo del Sistema...");
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opt != 4); 
    }
    
    private static void gestionarEntrenadores(Scanner scanner){
        
        int opt;
        
        do {
            System.out.println("--- Gestion de Entrenadores ---");
            System.out.println("1. Registrar Entrenador.");
            System.out.println("2. Mostrar Entrenadores.");
            System.out.println("3. Regresar al Menu Principal.");
            opt = scanner.nextInt();
            
            switch (opt) {
                case 1:
                    registrarEntrenador(scanner);
                    break;
                case 2:
                    mostrarEntrenadores();
                    break;
                case 3:
                    System.out.println("Regresando al Menu Principal...");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opt != 3); 
    }
    
    private static void registrarEntrenador(Scanner scanner){
        
        System.out.println("Ingresa el Nombre del Entrenador: ");
        String nombre = scanner.next();
        System.out.println("Ingresa su Especialidad Deportiva: ");
        String especialidad = scanner.next();
        System.out.println("Ingresa los Años de Experiencia: ");
        int experiencia = scanner.nextInt();
        
        entrenadores.add(new Entrenador(nombre, especialidad, experiencia));
        System.out.println("Exitosamente Resgistraste un Nuevo Entrenador");
    }
    
    private static void mostrarEntrenadores(){
        
        if(entrenadores.isEmpty()){
            System.out.println("No Tienes Entrenadores Registrados.");
        } else{
            System.out.println("--- Tus Entrenadores ---");
            for(Entrenador entrenador : entrenadores){
                System.out.println(entrenador);
            }
        }
    }
    
    private static void gestionDeportistas(Scanner scanner){
        
        int opt;
        
        do {
            System.out.println("--- Gestion de Deportistas ---");
            System.out.println("1. Registrar Deportista.");
            System.out.println("2. Mostrar Deportistas.");
            System.out.println("3. Regresar al Menu Principal.");
            opt = scanner.nextInt();
            
            switch (opt) {
                case 1:
                    registrarDeportista(scanner);
                    break;
                case 2:
                    mostrarDeportistas();
                    break;
                case 3:
                    System.out.println("Regresando al Menu Principal...");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opt != 3); 
    }
    
    private static void registrarDeportista(Scanner scanner){
        
        System.out.println("Ingresa el Nombre del Deportista: ");
        String nombre = scanner.next();
        System.out.println("Ingresa su Edad: ");
        int edad = scanner.nextInt();
        System.out.println("Ingresa el Deporte que Practica: ");
        String deporte = scanner.next();
        
        deportistas.add(new Deportista(nombre, edad,deporte));
        System.out.println("Exitosamente Resgistraste un Nuevo Deportista");
    }
    
    private static void mostrarDeportistas(){
        
        if(deportistas.isEmpty()){
            System.out.println("No Tienes Deportistas Registrados.");
        } else{
            System.out.println("--- Tus Deportistas ---");
            for(Deportista deportista : deportistas){
                System.out.println(deportista);
            }
        }
    }
       
    private static void gestionEquipos(Scanner scanner){
        
        int opt;
        
        do {
            System.out.println("--- Gestion de Equipos ---");
            System.out.println("1. Registrar Equipo.");
            System.out.println("2. Mostrar Equipos.");
            System.out.println("3. Regresar al Menu Principal.");
            opt = scanner.nextInt();
            
            switch (opt) {
                case 1:
                    registrarEquipo(scanner);
                    break;
                case 2:
                    mostrarEquipos();
                    break;
                case 3:
                    System.out.println("Regresando al Menu Principal...");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opt != 3); 
    }
    
    private static void registrarEquipo(Scanner scanner){
        
        System.out.println("Ingresa el Nombre del Equipo: ");
        String nombre = scanner.next();
        System.out.println("Ingresa la Categoria (juvenil/profesional): ");
        String categoria = scanner.next();
        
        Equipo equipo = new Equipo(nombre, categoria);
        equipos.add(equipo);
        System.out.println("Exitosamente Resgistraste un Nuevo Equipo");
    }
    
    private static void mostrarEquipos(){
        
        if(equipos.isEmpty()){
            System.out.println("No Tienes Equipos Registrados.");
        } else{
            System.out.println("--- Tus Equipos ---");
            for(Equipo equipo : equipos){
                System.out.println(equipo);
            }
        }
    }
}
